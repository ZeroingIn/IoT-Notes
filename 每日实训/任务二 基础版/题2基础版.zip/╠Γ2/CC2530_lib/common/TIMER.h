void Timer4_Init(void);
void Timer4_On(void);
void Timer4_Off(void);
uint8 GetSendDataFlag(void);