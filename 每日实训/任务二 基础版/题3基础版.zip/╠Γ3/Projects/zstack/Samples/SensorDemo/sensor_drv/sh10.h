/*************************************************************************************************
  Filename:       sh10.h
 
 *****/


#ifndef SIMPLE_SH10_H
#define SIMPLE_SH10_H

extern  void call_sht11( int16 *tem,int16 *hum); 
extern  void connectionreset(void);
#endif


